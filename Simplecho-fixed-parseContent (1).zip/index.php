<?php
/**
 * Simple + Echo = 💖
 * 
 * @package Simplecho
 * @author XiaoXi
 * @version 0.1.21
 * @link https://soraharu.com/
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$this->need('header.php');
?>

<div class="container mt-5">
	<div class="row">
		<!-- 主内容区域 -->
		<div class="col-lg-8 offset-lg-2">
			<!-- 置顶文章 -->
			<?php if ($this->is('index') && $this->_currentPage == 1): // 判断是否是首页 分页不输出 - 这段删了就是全站置顶 ?>
				<?php if ($this->options->sticky): ?>
				<div class="sticky-posts mb-6">
					<?php $this->options->sticky(); // 输出后台设置的手动置顶 ?>
				</div>
				<?php endif; ?>
			<?php endif; ?>

			<!-- 文章列表 -->
			<div class="post-list">
				<?php $index = 0; ?>
		<?php while ($this->next()): ?>
		<?php $index++; ?>
		<?php $animationClass = ($this->options->globalAnimations == 'enable' && $this->options->postListAnimation == 'enable') ? 'fade-in-up' : ''; ?>
		<?php $delay = ($this->options->animationDelay) ? intval($this->options->animationDelay) : 50; ?>
		<div class="post-item card-post <?php echo $animationClass; ?>" style="<?php echo $animationClass ? 'animation-delay: ' . ($index * $delay) . 'ms' : ''; ?>">
					<?php if (hasImage($this) == 1): ?>
					<div class="post-thumbnail">
						<a href="<?php $this->permalink(); ?>" class="d-block">
							<img src="<?php showThumbnail($this); ?>" alt="<?php $this->title(); ?>" class="w-100 h-64 object-cover rounded-t-lg">
						</a>
					</div>
					<?php endif; ?>
					
					<div class="card-body">
						<div class="post-meta-top flex items-center justify-between mb-3">
							<div class="post-category">
								<?php $this->category(''); ?>
							</div>
							<?php if ($this->sticky): ?>
							<span class="sticky-badge px-2 py-1 bg-primary text-white text-xs rounded-full">置顶</span>
							<?php endif; ?>
						</div>
						
						<h2 class="post-title text-xl md:text-2xl font-bold mb-3">
							<a href="<?php $this->permalink(); ?>" class="text-primary-hover transition-all">
								<?php $this->title(); ?>
							</a>
						</h2>
						
						<div class="post-excerpt mb-5 text-secondary line-clamp-3">
							<p><?php $this->excerpt('180', '...'); ?></p>
						</div>
						
						<div class="post-meta-bottom flex items-center justify-between text-sm text-muted">
							<time class="post-time">
								<i class="fas fa-calendar-alt mr-1"></i> <?php $this->date('Y年m月d日'); ?>
							</time>
							<div class="post-tags flex gap-2">
								<?php $this->tags(' ', true, ''); ?>
							</div>
						</div>
					</div>
				</div>
				<?php endwhile; ?>
			</div>

			<!-- 分页 -->
			<div class="pagination mt-8 text-center">
				<?php $this->pageLink('&laquo; 上一页'); ?>
				<span class="mx-3">
					第 <?php if ($this->_currentPage > 1) echo $this->_currentPage; else echo 1; ?> 页 / 共 <?php echo ceil($this->getTotal() / $this->parameter->pageSize); ?> 页
				</span>
				<?php $this->pageLink('下一页 &raquo;', 'next'); ?>
			</div>
		</div>
	</div>
</div>

<div class="pagination-container">

	<?php $this->pageLink('上一页'); ?>
	当前页码：<?php if ($this->_currentPage > 1) echo $this->_currentPage; else echo 1; ?>
	·
	总页码：<?php echo ceil($this->getTotal() / $this->parameter->pageSize); ?>
	<?php $this->pageLink('下一页', 'next'); ?>

</div>

<?php $this->need('footer.php'); ?>
