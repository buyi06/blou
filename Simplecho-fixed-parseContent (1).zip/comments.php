<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php if ($this->options->gravatarPrefix): ?>
<?php define('__TYPECHO_GRAVATAR_PREFIX__', $this->options->gravatarPrefix); ?>
<?php endif; ?>

<!-- 加载动画 -->
<div class="loading-indicator"><div class="loader"></div></div>

<?php function threadedComments($comments, $singleCommentOptions) {
	$commentClass = '';
	$Identity = '';
	if ($comments->authorId) {
		if ($comments->authorId == $comments->ownerId) {
			$commentClass .= ' comment-by-author';
			// 使用更简洁的作者标识
			$Identity = '<span class="author-badge">作者</span>';
		} else {
			$commentClass .= ' comment-by-user';
		}
	}
	$depth = $comments->levels + 1;
?>

<li id="<?php $comments->theId(); ?>" class="comment-body p-4 rounded-lg shadow-sm mb-4 bg-white dark:bg-gray-800 transition-all duration-300<?php
	if ($depth > 1) {
		echo ' comment-child ml-4 pl-6 border-l-2 border-gray-200 dark:border-gray-700';
		if ($depth > 2) {
			echo ' comment-child2 ml-8';
		}
	} else {
		echo ' comment-parent';
	}
	$comments->alt(' comment-odd', ' comment-even');
	echo $commentClass;
	?>">

	<div class="comment-author flex items-start gap-3">
			<!-- 设置头像类名并添加深色模式支持 -->
			<div class="avatar-container">
				<img src="<?php echo customGravatar($comments->mail, $singleCommentOptions->avatarSize, $singleCommentOptions->defaultAvatar); ?>" alt="<?php $comments->author(); ?>" class="avatar rounded-full transition-all hover:scale-105" width="<?php echo $singleCommentOptions->avatarSize; ?>" height="<?php echo $singleCommentOptions->avatarSize; ?>" />
			</div>

			<div class="comment-info flex-1">
				<div class="flex flex-wrap items-center justify-between gap-2">
					<cite class="fn font-medium mr-2">
						<?php $singleCommentOptions->beforeAuthor();
						CommentAuthor($comments); $singleCommentOptions->afterAuthor(); ?>
						<?php echo $Identity; ?>
					</cite>
					<div class="comment-meta text-sm text-gray-500 dark:text-gray-400">
						<a href="<?php $comments->permalink(); ?>" class="hover:text-primary transition-colors">
							<?php $comments->date($singleCommentOptions->dateFormat); ?>
						</a>
					</div>
				</div>
				<div class="comment-reply mt-1">
					<?php $comments->reply('<span class="reply-btn text-sm text-primary hover:underline">回复</span>'); ?>
				</div>
			</div>
		</div>
	<div class="comment-content mt-3 text-gray-800 dark:text-gray-200 break-words">
			<?php if(get_comment_at($comments->coid)): ?>
			<div class="comment-at text-sm text-gray-600 dark:text-gray-400 mb-1">
				<?php get_comment_at($comments->coid); ?>
			</div>
			<?php endif; ?>
			<!-- 移除境外CDN引用，使用本地表情图片路径 -->
			<?php echo preg_replace('#\@\((.*?)\)#', '<img src="/images/alu/$1.png" class="emoji inline-block align-middle" width="20" height="20">', $comments->content); ?>
		</div>
	<?php if ($comments->children) { ?>
	<div class="comment-children mt-4" id="pllc">
		<?php $comments->threadedComments($singleCommentOptions); // 评论嵌套 ?>
	</div>
	<?php } ?>
</li>
<?php } ?>

<section id="comments">
	<?php $this->comments()->to($comments); ?>
	<?php if ($this->allow('comment')): ?>
	<div id="<?php $this->respondId(); ?>" class="respond mt-6 p-5 rounded-lg shadow-sm bg-white dark:bg-gray-800">

		<h3 class="text-xl font-bold mb-4 text-gray-900 dark:text-white">
			<span class="cancel-comment-reply" id="response">
				<?php _e('添加新评论'); ?><?php $comments->cancelReply('<span class="ml-2 text-primary hover:underline">取消回复</span>'); ?>
			</span>
		</h3>
		<form method="post" action="<?php $this->commentUrl(); ?>" id="comment-form" role="form" class="comment-form">
			<div class="comment-form-container">
				<?php if ($this->user->hasLogin()): ?>
				<div class="login-info p-3 mb-4 bg-gray-50 dark:bg-gray-700 rounded-md">
					<p class="text-sm text-gray-700 dark:text-gray-300"><?php _e('登录身份: '); ?><a href="<?php $this->options->profileUrl(); ?>" class="font-medium text-primary"><?php $this->user->screenName(); ?></a>. <a href="<?php $this->options->logoutUrl(); ?>" title="Logout" class="text-primary hover:underline"><?php _e('退出'); ?> &raquo;</a></p>
				</div>
				<?php else: ?>
				<div class="form-info grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
					<input type="text" name="author" placeholder="昵称(*)" id="author" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all" value="<?php $this->remember('author'); ?>" required />
					<input type="email" name="mail" placeholder="邮箱(*)" id="mail" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all" value="<?php $this->remember('mail'); ?>"<?php if ($this->options->commentsRequireMail): ?> required<?php endif; ?> />
					<input type="url" name="url" placeholder="网址(可选)" id="url" class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all" placeholder="<?php _e('http://'); ?>" value="<?php $this->remember('url'); ?>"<?php if ($this->options->commentsRequireURL): ?> required<?php endif; ?> />
				</div>
				<?php endif; ?>
				<div class="mb-4">
					<textarea placeholder="写下你的评论..." rows="6" cols="50" class="OwO-textarea w-full px-3 py-3 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-primary/50 resize-y transition-all" name="text" id="textarea" required><?php $this->remember('text'); ?></textarea>
				</div>
				<div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
					<div class="OwO"></div>
					<button type="submit" id="submit" class="submit px-6 py-2 bg-primary text-white rounded-md hover:bg-primary/90 active:bg-primary/80 transition-all shadow-sm">发表评论</button>
				</div>
			</div>
		</form>
	</div>
	<?php if ($comments->have()): ?>
	<h3><?php $this->commentsNum(_t('暂无评论'), _t('仅有一条评论'), _t('已有 %d 条评论')); ?></h3>
	<div data-no-instant id="pllb">
	<?php $comments->listComments(); ?>
	</div>
	<?php $comments->pageNav('&laquo; 前一页', '后一页 &raquo;'); ?>		
	<?php endif; ?>
	<?php else: ?>
	<h3><?php _e('评论已关闭'); ?></h3>
	<?php endif; ?>
	<?php if ($this->options->baiduPush === 'enable' && !empty($this->options->baiduPushUrl)): ?>
	<div style="margin-top: 20px;">
		<svg viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" width="20" height="20">
			<path d="M656.26112 347.20768a188.65152 188.65152 0 1 0 0 324.04992V347.20768z" fill="#F4CA1C"></path>
			<path d="M668.34944 118.88128a73.34912 73.34912 0 0 0-71.168-4.06016L287.17056 263.5008a4.608 4.608 0 0 1-2.01216 0.4608H130.048A73.728 73.728 0 0 0 56.32 337.59744v349.63968a73.728 73.728 0 0 0 73.728 73.63584h156.55424a4.67968 4.67968 0 0 1 1.94048 0.43008l309.59104 143.19616a73.7024 73.7024 0 0 0 104.66816-66.82112V181.20704a73.216 73.216 0 0 0-34.45248-62.32576zM125.40416 687.23712V337.59744a4.608 4.608 0 0 1 4.608-4.608h122.0352v358.88128H130.048a4.608 4.608 0 0 1-4.64384-4.6336z m508.31872 150.44096a4.608 4.608 0 0 1-6.56384 4.19328l-306.02752-141.55264V323.77344l305.9712-146.72384a4.608 4.608 0 0 1 6.62016 4.15744v656.47104z m304.5376-358.95808h-150.25152a34.5088 34.5088 0 1 0 0 69.0176h150.25152a34.5088 34.5088 0 1 0 0-69.0176z m-128.25088-117.76a34.44736 34.44736 0 0 0 24.41728-10.10176L940.672 244.736a34.52416 34.52416 0 0 0-48.83968-48.80896L785.5872 302.08a34.5088 34.5088 0 0 0 24.4224 58.88z m24.41728 314.60864a34.52416 34.52416 0 1 0-48.83968 48.81408l106.24512 106.1376a34.52416 34.52416 0 0 0 48.83968-48.80896z" fill="#595BB3"></path>
		</svg>
		<?php
		$cxurl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		function okBaidu($url, $baiduPushUrl) {
			$url = 'https://www.baidu.com/s?wd=' . $url;
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			$rs = curl_exec($curl);
			curl_close($curl);
			if (!strpos($rs, '提交网址')) {
				echo "文章状态：已收录~";
			} else {
				$pageURL = (@$_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';
				$pageURL .= $_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
				$urls = array(
					$pageURL
				);
				$api = $baiduPushUrl;
				$ch = curl_init();
				$options = array(
					CURLOPT_URL => $api,
					CURLOPT_POST => true,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_POSTFIELDS => implode("\n", $urls),
					CURLOPT_HTTPHEADER => array('Content-Type: text/plain')
				);
				curl_setopt_array($ch, $options);
				// 返回结果是 json 形式
				$res = json_decode(curl_exec($ch), true);

				$ed = ($res['remain']); // 当天剩余的可推送 url 条数
				$cg = ($res['success']); // 成功推送的 url 条数

				echo "文章状态：未收录，已推送~ 【今日剩余额度：$ed 条】";
			}
		}
		echo okBaidu($cxurl, $this->options->baiduPushUrl);
		?>
	</div>
	<?php endif; ?>
</section>

<script>
	var OwO_demo = new OwO({
		logo: '表情',
		container: document.getElementsByClassName('OwO')[0],
		target: document.getElementsByClassName('OwO-textarea')[0],
		// 使用本地路径替代境外CDN
		api: '/assets/json/OwO.json',
		position: 'down',
		width: '100%',
		maxHeight: '250px'
	});
</script>

<script type="text/javascript">
var TypechoComment={dom:function(id){return document.getElementById(id);},create:function(tag,attr){var el=document.createElement(tag);for(var key in attr){el.setAttribute(key,attr[key]);}
return el;},reply:function(cid,coid){var comment=this.dom(cid),parent=comment.parentNode,response=this.dom('respond-post-286'),input=this.dom('comment-parent'),form='form'==response.tagName?response:response.getElementsByTagName('form')[0],textarea=response.getElementsByTagName('textarea')[0];if(null==input){input=this.create('input',{'type':'hidden','name':'parent','id':'comment-parent'});form.appendChild(input);}
input.setAttribute('value',coid);if(null==this.dom('comment-form-place-holder')){var holder=this.create('div',{'id':'comment-form-place-holder'});response.parentNode.insertBefore(holder,response);}
comment.appendChild(response);this.dom('cancel-comment-reply-link').style.display='';if(null!=textarea&&'text'==textarea.name){textarea.focus();}
return false;},cancelReply:function(){var response=this.dom('respond-post-286'),holder=this.dom('comment-form-place-holder'),input=this.dom('comment-parent');if(null!=input){input.parentNode.removeChild(input);}
if(null==holder){return true;}
this.dom('cancel-comment-reply-link').style.display='none';holder.parentNode.insertBefore(response,holder);return false;}}
</script>

<script type="text/javascript">
(function(){const reply=function(cid,coid){var comment=this.dom(cid),parent=comment.parentNode,<?php if($this->is('post')):?>response=this.dom('respond-post-<?php $this->cid() ?>'),input=this.dom('comment-parent'),<?php elseif($this->is('page')):?>response=this.dom('respond-page-<?php $this->cid() ?>'),input=this.dom('comment-parent'),<?php endif;?>form='form'==response.tagName?response:response.getElementsByTagName('form')[0],textarea=response.getElementsByTagName('textarea')[0];if(null==input){input=this.create('input',{'type':'hidden','name':'parent','id':'comment-parent'});form.appendChild(input);}
input.setAttribute('value',coid);if(null==this.dom('comment-form-place-holder')){var holder=this.create('div',{'id':'comment-form-place-holder'});response.parentNode.insertBefore(holder,response);}
comment.appendChild(response);this.dom('cancel-comment-reply-link').style.display='';if(null!=textarea&&'text'==textarea.name){textarea.focus();}
return false;}
const cancelReply=function(){<?php if($this->is('post')):?>var response=this.dom('respond-post-<?php $this->cid() ?>'),<?php elseif($this->is('page')):?>var
response=this.dom('respond-page-<?php $this->cid() ?>'),<?php endif?>holder=this.dom('comment-form-place-holder'),input=this.dom('comment-parent');if(null!=input){input.parentNode.removeChild(input);}
if(null==holder){return true;}
this.dom('cancel-comment-reply-link').style.display='none';holder.parentNode.insertBefore(response,holder);return false;}
if(window.TypechoComment){window.TypechoComment.reply=reply
window.TypechoComment.cancelReply=cancelReply}else{(()=>{window.TypechoComment={dom:function(id){return document.getElementById(id);},create:function(tag,attr){var el=document.createElement(tag);for(var key in attr){el.setAttribute(key,attr[key]);}
return el;},reply:function(cid,coid){var comment=this.dom(cid),parent=comment.parentNode,response=this.dom('respond-post-<?php $this->cid() ?>'),input=this.dom('comment-parent'),form='form'==response.tagName?response:response.getElementsByTagName('form')[0],textarea=response.getElementsByTagName('textarea')[0];if(null==input){input=this.create('input',{'type':'hidden','name':'parent','id':'comment-parent'});form.appendChild(input);}
input.setAttribute('value',coid);if(null==this.dom('comment-form-place-holder')){var holder=this.create('div',{'id':'comment-form-place-holder'});response.parentNode.insertBefore(holder,response);}
comment.appendChild(response);this.dom('cancel-comment-reply-link').style.display='';if(null!=textarea&&'text'==textarea.name){textarea.focus();}
return false;},cancelReply:function(){var response=this.dom('respond-post-<?php $this->cid() ?>'),holder=this.dom('comment-form-place-holder'),input=this.dom('comment-parent');if(null!=input){input.parentNode.removeChild(input);}
if(null==holder){return true;}
this.dom('cancel-comment-reply-link').style.display='none';holder.parentNode.insertBefore(response,holder);return false;}};})();}})();
</script>

<script type="text/javascript">
$(function()
{$('#comment-form').submit(function()
{var form=$(this),params=form.serialize();params+='&themeAction=comment';var appendComment=function(comment)
{var el=$('#comments > #pllb');if(0!=comment.parent)
{var el=$('#comment-'+comment.parent);if(el.find('.comment-children').length<1)
{$('<div class="comment-children" id="pllc"><ol class="comment-list"></ol></div>').appendTo(el);}
else if(el.find('.comment-children > .comment-list').length<1){$('<ol class="comment-list"></ol>').prependTo(el.find('.comment-children'));}
el=$('#comment-'+comment.parent).find('.comment-children').find('.comment-list');}
if(0==el.length)
{$('<ol class="comment-list"></ol>').prependTo($('#comments'));el=$('#comments > .comment-list');}
var html='<li id="comment-{coid}" class="comment-body comment-ajax comment-parent comment-odd"> <div class="comment-author"> <img class="avatar" src="{avatar}" alt="{author}" width="32" height="32"> <div class="comment-info"> <cite class="fn"><a href="{url}" rel="external nofollow" target="_blank">{author}</a></cite>  <em class="comment-meta"><a href="{permalink}">{datetime}</a></em> </div> <div class="comment-reply"><a href="{permalink}" rel="nofollow" onclick="return TypechoComment.reply(\'\comment-{coid}\'\, {coid});">回复</a></div> </div> <div class="comment-content">{content}</div> </li>';$.each(comment,function(k,v)
{regExp=new RegExp('{'+k+'}','g');html=html.replace(regExp,v);});var reg1=/@\(([^ ]*)\)/g;
				html=html.replace(reg1,"<img src=\"/images/alu/$1.png\" class=\"emoji inline-block align-middle\" width=\"20\" height=\"20\">");$(html).prependTo(el);}
$.ajax({url:'<?php $this->permalink();?>',type:'POST',data:params,dataType:'json',beforeSend:function()
{$(".loading").css("display","block");},complete:function()
{$(".loading").css("display","none");new NoticeJs({text:'评论成功（//▽//）',position:'middleCenter',animation:{open:'animated bounceInRight',close:'animated bounceOutLeft'}}).show();},success:function(result)
{if(1==result.status){appendComment(result.comment);form.find('textarea').val('');}
else{alert(undefined===result.msg?'<?php _e('评论出错!');?>':result.msg);}},error:function(xhr,ajaxOptions,thrownError)
{alert('评论失败，请重试');}});return false;});});
</script>
