// 深浅色模式自动匹配与切换逻辑
const expiredTime = new Date();
expiredTime.setTime(new Date().getTime() + 365 * 24 * 60 * 60 * 1000);

// 模式切换处理函数
function handleThemeChange(e) {
    const isDark = e.matches;
    const body = document.body;
    
    // 更新cookie记录当前模式
    document.cookie = `latest-prefers-color-scheme=${isDark ? 'dark' : 'light'}; expires=${expiredTime.toUTCString()}; path=/`;
    
    // 更新body类名
    if (isDark) {
        body.classList.add('dark');
        body.classList.remove('light');
    } else {
        body.classList.add('light');
        body.classList.remove('dark');
    }
    
    // 添加平滑过渡效果
    body.style.transition = 'background-color 0.3s ease, color 0.3s ease';
    
    // 触发自定义主题切换事件，便于其他组件响应
    window.dispatchEvent(new CustomEvent('themeChanged', { 
        detail: { isDark } 
    }));
}

// 初始检查并设置主题
const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
handleThemeChange(mediaQuery);

// 监听系统主题变化
mediaQuery.addEventListener('change', handleThemeChange);

// 导出切换函数供其他脚本调用
window.toggleTheme = function() {
    const isDark = document.body.classList.contains('dark');
    const newTheme = isDark ? 'light' : 'dark';
    
    document.cookie = `latest-prefers-color-scheme=${newTheme}; expires=${expiredTime.toUTCString()}; path=/`;
    
    if (newTheme === 'dark') {
        document.body.classList.add('dark');
        document.body.classList.remove('light');
    } else {
        document.body.classList.add('light');
        document.body.classList.remove('dark');
    }
    
    window.dispatchEvent(new CustomEvent('themeChanged', { 
        detail: { isDark: newTheme === 'dark' } 
    }));
}
