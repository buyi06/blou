/**
 * Simplecho 主题主JavaScript文件
 * 整合PJAX、懒加载、代码高亮等功能
 */

/**
 * 获取网站基础URL
 * 自动检测当前协议(http或https)，并构造完整的网站基础URL
 * @returns {string} 完整的网站基础URL，包含协议部分
 */
function getBaseUrl() {
    // 检测当前页面是否使用HTTPS协议
    var isHttps = 'https:' == document.location.protocol ? true : false;
    // 获取主机名（域名+端口）
    var url = window.location.host;
    // 根据协议类型拼接完整URL
    if (isHttps) {
        url = 'https://' + url;
    } else {
        url = 'http://' + url;
    }
    return url;
}

/**
 * 代码高亮初始化
 * 使用highlight.js库为页面中的代码块添加语法高亮效果
 * 此函数会在页面加载和PJAX导航后调用
 */
function initCodeHighlight() {
    // 检查highlight.js库是否已加载
    if (typeof hljs !== 'undefined') {
        // 查找页面中所有嵌套在<pre>标签内的<code>元素
        // 这是Markdown渲染后代码块的标准结构
        document.querySelectorAll('pre code').forEach((block) => {
            // 为每个代码块应用语法高亮
            hljs.highlightBlock(block);
        });
    }
}

/**
 * 图片懒加载初始化
 * 实现高效的图片懒加载功能，包括占位图显示、加载状态管理和兼容性处理
 * 优先使用Intersection Observer API，降级到传统滚动监听方案
 * @function initLazyLoad
 */
function initLazyLoad() {
    // 检查懒加载是否已启用
    const lazyLoadEnabled = document.documentElement.classList.contains('lazy-load-enabled');
    if (!lazyLoadEnabled) {
        console.log('懒加载功能已禁用');
        // 直接加载所有图片
        const lazyImages = document.querySelectorAll('img[data-src]');
        lazyImages.forEach(img => {
            if (img.dataset.src) {
                img.src = img.dataset.src;
                img.classList.add('loaded');
            }
        });
        return;
    }
    
    // 定义SVG占位图URL - 使用轻量级SVG替代原始JPG占位图
    const placeholderUrl = themeResourceUrl + '/assets/images/lazy-placeholder.svg';
    
    // 获取占位效果类型
    const placeholderType = document.documentElement.dataset.lazyLoadPlaceholder || 'animation';
    // 获取错误提示配置
    const showErrorTips = document.documentElement.dataset.lazyLoadErrorTips !== 'false';
    // 获取预加载距离
    const preloadDistance = parseInt(document.documentElement.dataset.lazyLoadDistance || 200);
    
    // 为所有懒加载图片设置占位图并添加样式
    document.querySelectorAll('img[data-src]').forEach((img) => {
        // 为图片添加懒加载类
        img.classList.add('lazy-image', 'loading');
        
        // 根据占位效果类型设置不同的样式
        switch (placeholderType) {
            case 'placeholder':
                // 使用占位图
                if (!img.getAttribute('src')) {
                    img.setAttribute('src', placeholderUrl);
                }
                break;
            case 'animation':
                // 使用加载动画
                img.classList.add('loading-animation');
                break;
            // 默认使用背景色
        }
        
        // 保存并设置原始宽高比，避免页面布局跳动
        if (img.width > 0 && img.height > 0) {
            img.style.aspectRatio = `${img.width} / ${img.height}`;
        }
    });
    
    // 使用原生Intersection Observer API实现懒加载（更现代高效）
    // Intersection Observer提供更好的性能，避免不必要的滚动事件监听
    if ('IntersectionObserver' in window) {
        // 创建Intersection Observer实例，监测元素是否进入视口
        const imageObserver = new IntersectionObserver((entries, observer) => {
            // 遍历所有监测到的元素
            entries.forEach((entry) => {
                // 当元素进入视口时触发加载
                if (entry.isIntersecting) {
                    const image = entry.target;
                    const dataSrc = image.getAttribute('data-src');
                    
                    if (dataSrc) {
                        
                        // 创建新图片对象进行预加载，避免直接修改原图片src导致的布局跳动
                        const newImg = new Image();
                        
                        // 图片加载成功的回调处理
                        newImg.onload = function() {
                            // 将预加载好的图片地址应用到原图片元素
                            image.setAttribute('src', dataSrc);
                            // 移除data-src属性，避免重复加载
                            image.removeAttribute('data-src');
                            // 标记为已加载状态，应用加载完成动画
                            image.classList.add('loaded');
                            // 移除加载中状态
                            image.classList.remove('loading');
                            
                            // 触发自定义加载完成事件，允许其他功能监听
                            const loadEvent = new CustomEvent('lazyload.complete', { bubbles: true });
                            image.dispatchEvent(loadEvent);
                            
                            // 不再观察该元素，优化性能
                            observer.unobserve(image);
                        };
                        
                        // 图片加载失败的回调处理
                        newImg.onerror = function() {
                            // 移除加载中状态
                            image.classList.remove('loading');
                            // 标记为错误状态，应用错误样式
                            image.classList.add('error');
                            
                            // 根据配置决定是否显示错误提示
                        if (showErrorTips) {
                            image.setAttribute('title', '图片加载失败');
                        }
                            
                            // 不再观察该元素
                            observer.unobserve(image);
                        };
                        
                        // 设置图片源，开始加载
                        newImg.src = dataSrc;
                    }
                };
            });
        }, {
            // 配置选项：
            // rootMargin: 提前指定像素开始加载图片，提升用户体验
            // threshold: 当图片可见部分达到1%时触发加载
            rootMargin: preloadDistance + 'px 0px', // 提前指定距离开始加载
            threshold: 0.01
        });

        // 为所有带有data-src属性的图片添加观察器
        document.querySelectorAll('img[data-src]').forEach((img) => {
            imageObserver.observe(img);
        });
    } else {
        // 降级方案：当浏览器不支持Intersection Observer时，使用传统的滚动事件监听
        // 这种方式兼容性更好，但性能相对较差
        const imgs = document.querySelectorAll('img[data-src]');
        
        // 图片加载函数，处理单个图片的加载逻辑
        const loadImg = function(img) {
            const dataSrc = img.getAttribute('data-src');
            if (dataSrc) {
                // 移除加载中状态
                img.classList.remove('loading');
                if (placeholderType === 'animation') {
                    img.classList.remove('loading-animation');
                }
                
                // 创建新图片对象预加载
                const newImg = new Image();
                newImg.onload = function() {
                    // 图片加载成功，更新属性和状态
                    img.setAttribute('src', dataSrc);
                    img.removeAttribute('data-src');
                    img.classList.add('loaded');
                };
                
                newImg.onerror = function() {
                    // 图片加载失败，更新状态和提示
                    img.classList.add('error');
                    
                    // 根据配置决定是否显示错误提示
                    if (showErrorTips) {
                        img.setAttribute('title', '图片加载失败');
                    }
                };
                
                // 设置图片源，开始加载
                newImg.src = dataSrc;
            }
        };
            
            // 设置图片源，开始加载
            newImg.src = dataSrc;
        }
    };

        // 滚动加载函数，在用户滚动页面时检查图片位置并加载可见图片
        const lazyLoad = function() {
            // 获取当前滚动位置和窗口高度
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            const windowHeight = window.innerHeight || document.documentElement.clientHeight;
            
            // 遍历所有懒加载图片
            imgs.forEach((img) => {
                // 检查图片是否未加载且不在加载中状态
                if (!img.classList.contains('loaded') && !img.classList.contains('loading')) {
                    // 获取图片相对于视口的位置
                    const rect = img.getBoundingClientRect();
                    // 当图片距离视口底部200px内时开始加载
                    if (rect.top <= windowHeight + 200) {
                        loadImg(img);
                    }
                }
            });
        };

        // 页面加载完成后立即执行一次，加载初始视口中的图片
        lazyLoad();
        // 滚动时执行加载函数，此处会应用节流优化以提升性能
        // 滚动节流实现 - 避免频繁触发滚动事件影响性能
        let lazyTimer;
        // 添加滚动事件监听
        window.addEventListener('scroll', () => {
            // 清除之前的定时器
            clearTimeout(lazyTimer);
            // 设置新的定时器，100毫秒后执行加载
            lazyTimer = setTimeout(lazyLoad, 100);
        });
    }
}

// 图片灯箱初始化
function initFancybox() {
    if (typeof $.fn.fancybox !== 'undefined') {
        // 为文章中的图片添加灯箱功能
        $('.post-content img').each(function(i) {
            if (!this.parentNode.href) {
                const imgSrc = this.getAttribute('data-src') || this.src;
                $(this).wrap("<a class='a_css' href='" + imgSrc + "' data-fancybox='fancybox' data-caption='" + randomString(8) + "'></a>");
            }
        });
        
        $('.fancybox').fancybox();
    }
}

// 初始化主题切换按钮
function initThemeToggle() {
    const themeToggleBtn = document.getElementById('theme-toggle');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', function() {
            // 调用match-dark-mode.js中定义的toggleTheme函数
            if (typeof toggleTheme === 'function') {
                toggleTheme();
            }
        });
    }
}

/**
 * 初始化滚动渐入动画
 * 使用Intersection Observer API实现元素进入视口时的平滑渐入动画效果
 * 该函数会自动检测元素位置，并在元素进入视口时触发CSS动画
 */
function initScrollReveal() {
    // 获取所有需要应用滚动渐入效果的元素
    const revealElements = document.querySelectorAll('.scroll-reveal');
    
    // 如果没有找到需要应用动画的元素，则直接退出
    if (revealElements.length === 0) return;
    
    // 创建Intersection Observer实例，用于监测元素是否进入视口
    const observer = new IntersectionObserver((entries) => {
        // 遍历所有监测到的元素
        entries.forEach(entry => {
            // 当元素进入视口时
            if (entry.isIntersecting) {
                // 添加active类以触发CSS动画
                entry.target.classList.add('active');
                // 一旦激活，就不再监测该元素，优化性能
                observer.unobserve(entry.target);
            }
        });
    }, {
        // 当元素的20%进入视口时触发动画
        threshold: 0.2,
        // 增加根边距，让元素在接近视口时就开始动画，提升用户体验
        rootMargin: '0px 0px -100px 0px'
    });
    
    // 为所有元素添加观察器
    revealElements.forEach(element => {
        observer.observe(element);
        
        // 检查元素是否已经在视口中
        // 这可以确保页面加载时已经可见的元素也能正确激活动画
        const rect = element.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom >= 0) {
            element.classList.add('active');
        }
    });
}

/**
 * 初始化滚动进度指示器
 * 在文章阅读页面显示一个顶部进度条，实时反映当前阅读进度
 * 采用固定在顶部的方式，提供直观的阅读位置反馈
 */
function initScrollProgress() {
    // 获取文章详情卡片元素
    const postDetailCard = document.querySelector('.post-detail-card');
    // 只有在文章详情页才初始化进度指示器
    if (postDetailCard) {
        const progressBar = postDetailCard.previousElementSibling;
        
        // 添加滚动事件监听
        window.addEventListener('scroll', function() {
            // 获取当前滚动位置
            const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            // 获取整个页面的高度
            const scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
            // 获取视口高度
            const clientHeight = document.documentElement.clientHeight || window.innerHeight;
            // 计算滚动百分比
            const scrollPercentage = (scrollTop / (scrollHeight - clientHeight)) * 100;
            
            // 尝试更新伪元素的CSS变量（作为后备方案）
            document.querySelector('.post-detail-card::before')?.style.setProperty('--progress-width', scrollPercentage + '%');
            
            // 由于CSS伪元素无法直接通过JavaScript修改，我们创建一个真实的DOM元素
            let progressIndicator = document.querySelector('#reading-progress');
            if (!progressIndicator) {
                // 创建进度条元素
                progressIndicator = document.createElement('div');
                progressIndicator.id = 'reading-progress';
                // 设置进度条样式
                progressIndicator.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 0;
                    height: 3px;
                    background-color: var(--primary-color);
                    z-index: 9999;
                    transition: width 0.1s ease;
                `;
                // 添加到页面中
                document.body.appendChild(progressIndicator);
            }
            // 更新进度条宽度以反映阅读进度
            progressIndicator.style.width = scrollPercentage + '%';
        });
    }
}

/**
 * 生成随机字符串
 * 用于创建唯一标识符、临时密码或其他需要随机性的场景
 * 故意排除了容易混淆的字符（如数字0和字母O），提高可读性
 * 
 * @param {number} len - 生成的随机字符串长度，默认为32位
 * @returns {string} 生成的随机字符串
 */
function randomString(len = 32) {
    // 使用不含易混淆字符的字符集
    const chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
    // 字符集长度
    const maxPos = chars.length;
    // 结果字符串
    let pwd = '';
    // 循环生成指定长度的随机字符串
    for (let i = 0; i < len; i++) {
        // 随机选择字符并添加到结果中
        pwd += chars.charAt(Math.floor(Math.random() * maxPos));
    }
    return pwd;
}

/**
 * 初始化页面滚动功能
 * 为页面中的滚动按钮添加平滑滚动到顶部和底部的功能
 * 提升用户在长页面中的导航体验
 */
function initScrollButtons() {
    // 为返回顶部按钮添加点击事件
    $('#lamu').on('click', function() {
        // 使用平滑滚动效果返回页面顶部
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
        return false;
    });
    
    // 为滚动到底部按钮添加点击事件
    $('#leimu').on('click', function() {
        // 平滑滚动到页面底部
        // 获取文档总高度作为滚动目标位置
        window.scrollTo({
            top: document.documentElement && document.documentElement.scrollHeight || document.body.scrollHeight,
            behavior: "smooth" // 使用平滑滚动动画
        });
        return false;
    });
}

// Mermaid图表初始化
function initMermaid() {
    if (typeof mermaid !== 'undefined') {
        mermaid.init({noteMargin: 10}, '.lang-mermaid');
    }
}

// 初始化主题切换事件监听
function initThemeListener() {
    window.addEventListener('themeChanged', function() {
        initCodeHighlight(); // 主题切换时重新高亮代码
    });
}

// 修复无标题文章链接问题
function fixUntitledPostLinks() {
    document.querySelectorAll('#thePrevTitle, #theNextTitle').forEach(function(el) {
        el.innerHTML = el.innerHTML.replace('></a>', '>无标题文章</a>');
    });
}

// PJAX初始化和页面刷新处理
function initPJAX() {
    // 初始化PJAX
    $(document).pjax('a[href^=' + '"' + getBaseUrl() + '"' + ']:not(a[target="_blank"], a[no-pjax])', {
        container: '#pjax',
        fragment: '#pjax',
        timeout: 8000
    });
    
    // 表单无刷新提交
    $(document).on('submit', '#gridea-search-form', function(event) {
        $.pjax.submit(event, '#pjax', {
            fragment: '#pjax',
            timeout: 6000
        });
    });
    
    // PJAX开始时的处理
    $(document).on('pjax:start', function() {
        if (typeof NProgress !== 'undefined') {
            NProgress.start();
        }
    });
    
    // PJAX完成时的处理（重新初始化各种组件）
      $(document).on('pjax:complete', function() {
        // 重新初始化代码高亮
        initCodeHighlight();
        // 重新初始化懒加载
        initLazyLoad();
        // 重新初始化图片灯箱
        initFancybox();
        // 重新初始化滚动按钮
        initScrollButtons();
        // 初始化Mermaid图表
        initMermaid();
        // 初始化滚动进度指示器
        initScrollProgress();
        // 初始化主题切换按钮
        initThemeToggle();
        // 初始化滚动渐入动画
        initScrollReveal();
        // 修复无标题文章链接
        fixUntitledPostLinks();
            
            // 触发自定义事件通知其他组件页面已更新
        const event = new CustomEvent('pageUpdated');
        window.dispatchEvent(event);
        });
    
    // PJAX结束时的处理
    $(document).on('pjax:end', function() {
        if (typeof NProgress !== 'undefined') {
            NProgress.done();
        }
    });
    
    // 错误处理
    $(document).on('pjax:error', function(event, xhr, textStatus, error) {
        console.error('PJAX加载错误:', textStatus, error);
        if (typeof NProgress !== 'undefined') {
            NProgress.done();
        }
    });
}

// 文档加载完成后初始化所有功能
$(document).ready(function() {
    initCodeHighlight();
    initLazyLoad();
    initFancybox();
    initScrollButtons();
    initMermaid();
    initScrollProgress();
    initThemeListener();
    initThemeToggle();
    fixUntitledPostLinks();
    initScrollReveal();
    
    // 仅在支持PJAX的浏览器中初始化
    if (typeof $.fn.pjax !== 'undefined') {
        initPJAX();
    }
    
    // 页面加载完成通知
    if (typeof NoticeJs !== 'undefined') {
        new NoticeJs({
            text: '页面加载完成~',
            position: 'topRight',
            animation: {
                open: 'animated bounceInRight',
                close: 'animated bounceOutLeft'
            }
        }).show();
    }
});