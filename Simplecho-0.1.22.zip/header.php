<!DOCTYPE html>
<html lang="zh-Hans"<?php
    // 输出懒加载相关配置
    if (@$this->options->enableLazyLoad) {
        echo ' class="lazy-load-enabled"';
        echo ' data-lazy-load-placeholder="' . htmlspecialchars(@$this->options->lazyLoadPlaceholder) . '"';
        echo ' data-lazy-load-error-tips="' . htmlspecialchars(@$this->options->lazyLoadErrorTips) . '"';
        echo ' data-lazy-load-distance="' . htmlspecialchars(@$this->options->lazyLoadDistance ?: 200) . '"';
    }
?>>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="renderer" content="webkit" />
	<meta name="force-rendering" content="webkit" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>
		<?php $this->archiveTitle(array(
			'category'	=>	_t('分类 %s 下的文章'),
			'search'	=>	_t('包含关键字 %s 的文章'),
			'tag'		=>	_t('标签 %s 下的文章'),
			'author'	=>	_t('%s 发布的文章')
		), '', ' - '); ?><?php if ($this->_currentPage > 1) echo '第 ' . $this->_currentPage . ' 页 - '; ?><?php $this->options->title(); ?><?php if ($this->is('index') && !empty($this->options->summary)): ?> - <?php $this->options->summary(); ?><?php endif; ?>
	</title>
	<?php $this->header(); ?>
	<?php if ($this->options->favicon): ?>
<link href="<?php $this->options->favicon(); ?>" rel="shortcut icon" />
<?php else: ?>
<link href="<?php echo themeResourceUrl('/images/icon.ico'); ?>" rel="shortcut icon" />
<?php endif; ?>
	<link rel="stylesheet" href="<?php echo themeResourceUrl('/assets/css/vendor/font-awesome.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo themeResourceUrl('/assets/css/main.css'); ?>" />
<?php
	if ($_COOKIE['latest-prefers-color-scheme']) {
		setcookie('latest-prefers-color-scheme', $_COOKIE['latest-prefers-color-scheme'], time() + 60 * 60 * 24 * 365, '/');
	}
?>
<!-- 主题颜色系统通过CSS变量实现，不再需要额外的主题CSS文件 -->
<link rel="stylesheet" href="<?php echo themeResourceUrl('/assets/css/vendor/bootstrap.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo themeResourceUrl('/assets/css/vendor/jquery.fancybox.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo themeResourceUrl('/assets/css/vendor/nprogress.min.css'); ?>" />
<link rel="stylesheet" href="<?php echo themeResourceUrl('/assets/css/vendor/OwO.min.css'); ?>" />

	<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/jquery.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/popper.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/bootstrap.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/highlight.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/jquery.fancybox.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/jquery.pjax.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/OwO.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo themeResourceUrl('/assets/js/vendor/console-ban.min.js'); ?>"></script>
</head>
<body class="theme-<?php $this->options->themeColor(); ?> <?php echo $_COOKIE['latest-prefers-color-scheme'] === 'dark' ? 'dark' : ''; ?>">
	<div class="main gt-bg-theme-color-first">
		<div class="main-content" id="pjax">
			<nav class="navbar navbar-expand-lg">
				<a href="<?php $this->options->siteUrl(); ?>">
					<div class="navbar-brand">
						<?php if ($this->options->logo): ?>
<img class="user-avatar" src="<?php $this->options->logo(); ?>" alt="头像" />
<?php else: ?>
<img class="user-avatar" src="<?php echo themeResourceUrl('/images/avatar.png'); ?>" alt="头像" />
<?php endif; ?>
						<div class="site-name gt-c-content-color-first">
							<?php $this->options->title(); ?>
						</div>
					</div>
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
					aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<i class="fas fa-bars gt-c-content-color-first" style="font-size: 18px"></i>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<div class="navbar-nav mr-auto" style="text-align: center">

						<div class="nav-item">
							<a href="<?php $this->options->siteUrl(); ?>" class="menu gt-a-link">🏠首页</a>
						</div>

						<?php $this->widget('Widget_Contents_Page_List')
							->parse('<div class="nav-item"><a href="{permalink}" class="menu gt-a-link">{title}</a></div>'); ?>
					</div>

					<div class="flex items-center gap-3">
						<!-- 深色模式切换按钮 -->
						<button id="theme-toggle" class="btn theme-toggle-btn" aria-label="切换深色模式">
							<i class="fas fa-moon theme-icon-dark gt-c-content-color-first"></i>
							<i class="fas fa-sun theme-icon-light gt-c-content-color-first"></i>
						</button>
							
						<form id="gridea-search-form" style="position: relative" action="<?php $this->options->siteUrl(); ?>" role="search">
							<input type="text" id="s" name="s" class="search-input" autocomplete="off" name="search" placeholder="搜索文章" />
							<i class="fas fa-search gt-c-content-color-first" style="position: absolute; top: 9px; left: 10px;"></i>
						</form>
					</div>


				</div>
			</nav>
