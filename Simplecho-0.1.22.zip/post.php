<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

<?php $this->need('header.php'); ?>

<div class="container mt-5 mb-10">
	<div class="row">
		<!-- 主内容区域 -->
		<div class="col-lg-8 offset-lg-2">
			<!-- 文章内容卡片 -->
			<div class="card post-detail-card">
				<article class="p-8">
					<!-- 文章标题 -->
				<?php if (!empty($this->title)): ?>
				<?php $animationClass = ($this->options->globalAnimations == 'enable') ? 'fade-in-up' : ''; ?>
		<h1 class="post-title text-3xl sm:text-4xl font-bold mb-6 leading-tight <?php echo $animationClass; ?>" style="<?php echo $animationClass ? 'animation-delay: 100ms' : '';">
			<?php $this->title(); ?>
					</h1>
					<?php else: ?>
					<br />
					<?php endif; ?>
					
					<!-- 文章元信息 -->
					<div class="post-meta flex flex-wrap items-center gap-4 mb-8 pb-4 border-b <?php echo $animationClass; ?>" style="<?php echo $animationClass ? 'animation-delay: 150ms' : ''; ?>">
						<time class="post-time text-muted hover:text-primary transition-colors">
							<i class="fa fa-calendar-o mr-1"></i> <?php $this->date('Y年m月d日'); ?>
						</time>
						
						<div class="post-category">
							<i class="fa fa-folder-o mr-1"></i> 
							<?php $this->category(' ', array('class' => 'text-secondary hover:text-primary transition-colors')); ?>
						</div>
						
						<?php if (count($this->tags) > 0): ?>
						<div class="post-tags flex flex-wrap gap-2">
							<i class="fa fa-tags mr-1"></i> 
							<?php $this->tags(' ', true, '', array('class' => 'text-secondary hover:text-primary transition-colors')); ?>
						</div>
						<?php if ($this->user->hasLogin()): ?>
						<div class="post-edit">
							<a href="<?php $this->options->adminUrl(); ?>write-post.php?cid=<?php $this->cid(); ?>" target="_blank" rel="noopener noreferrer" class="text-secondary hover:text-primary transition-colors">
								<i class="fa fa-pencil mr-1"></i>编辑
							</a>
						</div>
						<?php endif; ?>
						<?php endif; ?>
					</div>
					
					<!-- 文章内容 -->
					<div class="post-content article-content <?php echo $animationClass; ?>" style="<?php echo $animationClass ? 'animation-delay: 200ms' : ''; ?>">
						<?php parseContent($this); ?>
					</div>
					
					<!-- 文章结尾自定义区域 -->
					<?php
						if ($this->options->underPostContent) {
							echo '<div class="post-footer-custom mt-10 p-6 bg-secondary rounded-lg">';
							$this->options->underPostContent();
							echo '</div>';
						}
					?>
				</article>
			</div>

			<!-- 文章导航 -->
			<nav class="post-nav mb-12 py-6 border-t border-b">
				<div class="flex flex-col md:flex-row md:justify-between gap-4">
					<div class="post-nav-prev">
						<?php if ($this->isPrev()) : ?>
							<span class="block text-sm text-secondary mb-1">上一篇</span>
							<a href="<?php $this->thePrev('%s', '', array('title' => '')); ?>" class="post-nav-link hover:text-primary transition-colors">
								<?php $this->thePrev('%s', '', array('title' => '')); ?>
							</a>
						<?php else : ?>
							<span class="block text-sm text-secondary mb-1">上一篇</span>
							<span class="text-gray-400">没有了</span>
						<?php endif; ?>
					</div>
					<div class="post-nav-next text-right">
						<?php if ($this->isNext()) : ?>
							<span class="block text-sm text-secondary mb-1">下一篇</span>
							<a href="<?php $this->theNext('%s', '', array('title' => '')); ?>" class="post-nav-link hover:text-primary transition-colors">
								<?php $this->theNext('%s', '', array('title' => '')); ?>
							</a>
						<?php else : ?>
							<span class="block text-sm text-secondary mb-1">下一篇</span>
							<span class="text-gray-400">没有了</span>
						<?php endif; ?>
					</div>
				</div>
			</nav>

			<!-- 评论区 -->
			<div class="comments-section mt-12">
				<h3 class="text-2xl font-bold mb-6">评论</h3>
				<div class="card">
					<div class="p-6">
						<?php $this->need('comments.php'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- 无标题文章链接修复和主题切换逻辑已移至main.js -->

<?php $this->need('footer.php'); ?>
